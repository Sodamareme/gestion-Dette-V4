<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
use Core\Router;
use Controller\ClientController;
use Controller\UtilisateurController;

require_once 'vendor/autoload.php';
require_once '/var/www/html/boutique/src/Controller/UtilisateurController.php';
require_once '/var/www/html/boutique/src/Controller/ClientController.php';
// Définir les routes

Router::post('/rechercher_client', [ClientController::class, 'rechercher']);

// Exemple de définition de route pour saveClient (POST)
// Router::post('/saveClient', 'UtilisateurController@saveClient');

// Exemple de définition de route pour searchClient (GET)
// Router::get('/searchClient', 'UtilisateurController@searchClient');

// Autres routes pour votre application...

$client = new UtilisateurController;
// $client->searchClient();
// var_dump($clie lnt);
// routes.php
// routes/web.php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SERVER['REQUEST_URI'] === '/searchClient') {
    require_once __DIR__ . '/../src/Controller/UtilisateurController.php';
    $controller = new UtilisateurController();
    $controller->searchClient();
}


?>

