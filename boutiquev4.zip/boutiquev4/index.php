<?php
// require 'vendor/autoload.php';

// use App\App;
// use Core\Router;

// // Load environment variables
// $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
// $dotenv->load();

// $app = App::getInstance();

// $router = new Router();
// $router->get('/clients', 'ClientController@getAllClients');
// $router->post('/clients', 'ClientController@saveClient');
// // Add more routes as needed

// // Handle the incoming request
// $requestUri = $_SERVER['REQUEST_URI'];
// $requestMethod = $_SERVER['REQUEST_METHOD'];
// $response = $router->resolve($requestUri, $requestMethod);

// echo json_encode($response);

// require 'vendor/autoload.php';


// use App\App;
// use Core\Router;

// // Load environment variables
// $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
// $dotenv->load();

// $app = App::getInstance();

// $router = new Router();
// $router->get('/clients', 'ClientController@getAllClients');
// $router->post('/clients', 'ClientController@saveClient');
// // Add more routes as needed

// // Handle the incoming request
// $requestUri = $_SERVER['REQUEST_URI'];
// $requestMethod = $_SERVER['REQUEST_METHOD'];
// $response = $router->resolve($requestUri, $requestMethod);

// echo json_encode($response);
// require_once './src/Core/Router.php';


use Core\Router;
require_once 'vendor/autoload.php';
require_once './routes/web.php';
// $route->post('saveClient', ['controller' => 'UtilisateurController', 'action' => 'saveClient']);
// $route->separate();
?>
