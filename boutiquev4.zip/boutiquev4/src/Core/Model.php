<?php
namespace Core;

use Database\MysqlDatabase;

abstract class Model {
    
    protected $table;
    protected $database;

    public function __construct() {
        $this->database = MysqlDatabase::getInstance();
    }

    public function all() {
        return $this->query("SELECT * FROM {$this->table}");
    }

    public function find($id) {
        return $this->query("SELECT * FROM {$this->table} WHERE id = ?", [$id]);
    }

    public function query($statement, $attributes = null) {
        if ($attributes) {
            return $this->database->prepare($statement, $attributes);
        } else {
            return $this->database->query($statement);
        }
    }

    public function save($data) {
        // Implement save logic
    }

    public function delete($id) {
        return $this->query("DELETE FROM {$this->table} WHERE id = ?", [$id]);
    }

    public static function update($data, $id) {
        // Implement update logic
    }

    public function setDatabase($database) {
        $this->database = $database;
    }
}

