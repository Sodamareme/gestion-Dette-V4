<?php

// class Router {
//     private $routes = [];

//     public function post($uri, $controllerAction) {
//         $this->routes['POST'][$uri] = $controllerAction;
//     }

//     public function get($uri, $controllerAction) {
//         $this->routes['GET'][$uri] = $controllerAction;
//     }

//     public function resolve($requestUri, $requestMethod) {
//         if (isset($this->routes[$requestMethod][$requestUri])) {
//             list($controller, $action) = explode('@', $this->routes[$requestMethod][$requestUri]);
//             $controller = "Controller\\" . $controller;
//             $controllerInstance = new $controller();
//             return $controllerInstance->$action();
//         }
//         return null;
//     }
// }
// namespace Core;

// $routes = [
//     "dette/add" => ["controller" => "ExoController", "action" => "store"],

// ];

// function bonjour() {
//     echo "Bonjour!";
// }

// function router() {
//     global $routes;
//     $_GET['store'] = 'bonjour';
    
//     $uri = $_GET['store'];
//     if(isset($routes[$uri])) {
//         $controller = $routes[$uri]['controller'];
//         $action = $routes[$uri]['action'];
//         if(function_exists($action)) {
//             echo "Controller: $controller, Action: $action";
//         } else {
//             echo "404 - Fonction non trouvée";
//         }
//     } else {
//         echo "404 - Route non trouvée";
//     }
// }
// router();


// namespace Core;
// namespace Controller;
// $routes = [
//     "bonjour" => ["action" => "bonjour"],
//     "dette/add" => ["controller" => "ExoController", "action" => "store"],
// ];
// function router() {
//     global $routes;

//     $uri = isset($_GET['store']) ? $_GET['store'] : '';
//     if(isset($routes[$uri])) {
//         if(isset($routes[$uri]['controller']) && isset($routes[$uri]['action'])) {
//             $controllerName = $routes[$uri]['controller'];
//             $action = $routes[$uri]['action'];
//             $controller = new $controllerName();

//             if(method_exists($controller, $action)) {
//                 $controller->$action();
//             } else {
//                 echo "404 - Action non trouvée dans le contrôleur";
//             }
//         } else {
//             $action = $routes[$uri]['action'];
//             $functionName = "\\Core\\$action";
//             if(function_exists($functionName)) {
//                 $functionName();
//             } else {
//                 echo "404 - Fonction non trouvée";
//             }
//         }
//     } else {
//         echo "404 - Route non trouvée";
//     }
// }
// router();

namespace Core;

class Router {
    private static $routes = [];

    public static function get($uri, $config) {
        self::$routes[$uri] = $config;
    }

    public static function post($uri, $config) {
        self::$routes[$uri] = $config;
    }

    public static function route() {
        $requestedUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); 
        $requestedUri = trim($requestedUri, '/'); 
        $uriSegments = array_filter(explode('/', $requestedUri));
        $cleanUri = implode('/', $uriSegments);

        $matchedRoute = null;
        $params = [];

        foreach (self::$routes as $route => $config) {
            $route = trim($route, '/');
            $routeSegments = array_filter(explode('/', $route));
            $cleanRoute = implode('/', $routeSegments);

            $pattern = preg_replace('/#\w+/', '(\w+)', $cleanRoute);
            if (preg_match("@^{$pattern}$@", $cleanUri, $matches)) {
                $matchedRoute = $config;
                array_shift($matches);
                $params = $matches;
                break;
            }
        }

        if ($matchedRoute !== null) {
            if (isset($matchedRoute['controller']) && isset($matchedRoute['action'])) {
                $controllerName = "\\Controller\\" . $matchedRoute['controller'];
                $action = $matchedRoute['action'];

                if (class_exists($controllerName)) {
                    $reflectionClass = new \ReflectionClass($controllerName);
                    $controller = $reflectionClass->newInstanceWithoutConstructor();

                    if ($reflectionClass->hasMethod($action)) {
                        $method = $reflectionClass->getMethod($action);
                        $method->invokeArgs($controller, $params);
                    } else {
                        echo "404 - Action non trouvée dans le contrôleur";
                    }
                } else {
                    echo "404 - Contrôleur non valide";
                }
            } else {
                echo "404 - Configuration de route invalide";
            }
        } else {
            echo "";
        }
    }
}

// Définir les routes
Router::get('dette/add/#id/#date', ['controller' => 'ExoController', 'action' => 'show']);
Router::get('dette/add', ['controller' => 'ExoController', 'action' => 'store']);
Router::get('login', ['controller' => 'LoginController', 'action' => 'show']);
Router::get('clientsSuiviDette', ['controller' => 'ClientsSuiviController', 'action' => 'index']);
Router::post('saveClient', ['controller' => 'UtilisateurController', 'action' => 'saveClient']);


Router::route();


?>

