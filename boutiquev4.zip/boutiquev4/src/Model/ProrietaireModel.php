<?php
namespace Model;

use Core\Model;

class ProprietaireModel extends Model {
    protected $table = 'Proprietaire';

    // Implement specific methods as needed
}
