<?php

namespace Model;
use PDO;
use Core\Model;

class ClientModel extends Model {
    
    protected $table = 'Client';

    public function save($data) {
        $sql = "INSERT INTO {$this->table} (photo, nom, prenom, code, adresse, telephone, login, password, idProduit, idProprietaire) 
                VALUES (:photo, :nom, :prenom, :code, :adresse, :telephone, :login, :password, :idProduit, :idProprietaire)";
        $this->query($sql, $data);
    }

    public static function update($id, $data) {
        $sql = "UPDATE Client 
                SET photo = :photo, nom = :nom, prenom = :prenom, code = :code, adresse = :adresse, 
                    telephone = :telephone, login = :login, password = :password, idProduit = :idProduit, idProprietaire = :idProprietaire 
                WHERE idClient = :idClient";
        $data['idClient'] = $id;
        self::query($sql, $data);
    }
    protected $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function getClientByPhone($tel) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM Client WHERE tel = ?");
            $stmt->execute([$tel]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (\PDOException $e) { // Utiliser \PDOException ici
            // Gérer les erreurs de requête SQL
            echo 'Erreur de requête SQL : ' . $e->getMessage();
            return false;
        }
    }

    // public function getClientWithTotalDette($clientId) {
    //     // Récupérer les informations du client
    //     $sqlClient = "SELECT * FROM Client WHERE idClient = :clientId";
    //     $client = $this->database->prepare($sqlClient, ['clientId' => $clientId], \stdClass::class, true);
    
    //     if ($client) {
    //         // Récupérer la somme des dettes du client
    //         $sqlDette = "SELECT SUM(montant) as totalDette FROM Dette WHERE idClient = :clientId";
    //         $result = $this->database->prepare($sqlDette, ['clientId' => $clientId], \stdClass::class, true);
            
    //         // Ajouter la somme des dettes aux informations du client
    //         $client->totalDette = $result->totalDette ?? 0;
            
    //     }
    
    //     return $client;
    // }
    
}
