<?php
namespace Model;

use Core\Model;

class VendeurModel extends Model {
    protected $table = 'Vendeur';

    // Implement specific methods as needed
}
