<?php
namespace Controller;

class ErrorController {
    public function error() {
        echo '404 - Page not found';
    }
}
?>

