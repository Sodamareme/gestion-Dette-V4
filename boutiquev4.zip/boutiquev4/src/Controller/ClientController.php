<?php
namespace Controller;

use Core\Controller;
use Model\ClientModel;

class ClientController extends Controller {
    private $clientModel;

    public function __construct() {
        $this->clientModel = new __construct();
    }

    public function getAllClients() {
        return $this->clientModel->all();
    }

    public function getClientById($id) {
        return $this->clientModel->find($id);
    }

    public function saveClient($data) {
        return $this->clientModel->save($data);
    }

    public function updateClient($id, $data) {
        return $this->clientModel->update($id, $data);
    }

    public function deleteClient($id) {
        return $this->clientModel->delete($id);
    }
    
}



