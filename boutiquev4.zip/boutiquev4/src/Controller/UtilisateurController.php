<?php
namespace Controller;

use Core\Validator;
use Core\Controller;
use PDO;
use PDOException;

class UtilisateurController extends Controller
{
    public function index()
    {
        $this->redirect('clientsSuiviDette');
    }

    public function saveClient()
    {
        $valide = new Validator();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $valide->validate($_POST, [
                'nom' => ['required'],
                'prenom' => ['required'],
                'email' => ['required', "email"],
                'tel' => ['required', "tel"]
            ]);

            $errorMessage = $valide->getErrors();
            if (!$_FILES['photo']['name']) {
                $errorMessage['photo'] = 'Le photo est requise';
            }
            if (!count($errorMessage)) {
                $nom = $_POST['nom'];
                $prenom = $_POST['prenom'];
                $email = $_POST['email'];
                $tel = $_POST['tel'];
                $photo = $_FILES['photo']['name'];
                $login = 'mareme';
                $passwordClient = sha1('mareme1616');
                $uploadDir = './uploads/';
                $uploadFile = $uploadDir . basename($photo);
                if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadFile)) {
                    try {
                        $dsn = 'mysql:host=localhost;dbname=boutiquev4;charset=utf8mb4';
                        $username = 'soda';
                        $password = 'soda1616';
                        $options = [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        ];
                        $pdo = new PDO($dsn, $username, $password, $options);

                        $stmt = $pdo->prepare("INSERT INTO Client (nom, prenom, email, tel, photo, login, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$nom, $prenom, $email, $tel, $photo, $login, $passwordClient]);

                        $this->renderView('/clientsSuiviDette', ["success" => "Client enregistré avec succès!"]);
                    } catch (PDOException $e) {
                        echo 'Échec de la connexion à MySQL : ' . $e->getMessage();
                    }
                } else {
                    switch ($_FILES['photo']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                            echo "Le fichier dépasse la limite de taille spécifiée par PHP.";
                            break;
                        case UPLOAD_ERR_FORM_SIZE:
                            echo "Le fichier dépasse la limite de taille spécifiée dans le formulaire HTML.";
                            break;
                        case UPLOAD_ERR_PARTIAL:
                            echo "Le fichier n'a été que partiellement téléchargé.";
                            break;
                        case UPLOAD_ERR_NO_FILE:
                            echo "Aucun fichier n'a été téléchargé.";
                            break;
                        case UPLOAD_ERR_NO_TMP_DIR:
                            echo "Le dossier temporaire est manquant.";
                            break;
                        case UPLOAD_ERR_CANT_WRITE:
                            echo "Échec de l'écriture du fichier sur le disque.";
                            break;
                        case UPLOAD_ERR_EXTENSION:
                            echo "Une extension PHP a arrêté l'upload du fichier.";
                            break;
                        default:
                            echo "Erreur lors de l'upload de la photo.";
                            break;
                    }
                }
            } else {
                $this->renderView('/clientsSuiviDette', ["error" => $errorMessage]);
            }
        }
    }

    public function searchClient()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $tel = $_POST['telRecherche'] ?? '';
            $client = $this->getClientWithTotalDette($tel);

            if ($client) {
                $this->renderView('clientsSuiviDette', ['client' => $client]);
            } else {
                $errorMessage = 'Aucun client trouvé avec ce numéro de téléphone : ' . $tel;
                $this->renderView('clientsSuiviDette', ['errorMessage' => $errorMessage]);
            }
        } else {
            $errorMessage = 'Requête non valide.';
            $this->renderView('clientsSuiviDette', ['errorMessage' => $errorMessage]);
        }
    }

    public function getClientWithTotalDette($tel)
    {
        try {
            $dsn = 'mysql:host=localhost;dbname=boutiquev4;charset=utf8mb4';
            $username = 'soda';
            $password = 'soda1616';
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ];
            $pdo = new PDO($dsn, $username, $password, $options);

            // Rechercher le client par téléphone
            $stmt = $pdo->prepare("SELECT * FROM Client WHERE tel = ?");
            $stmt->execute([$tel]);
            $client = $stmt->fetch();

            if ($client) {
                // Calculer la somme des dettes du client
                $stmt = $pdo->prepare("SELECT SUM(montant) as totalDette FROM Dette WHERE idClient = ?");
                $stmt->execute([$client['idClient']]);
                $totalDette = $stmt->fetch();

                // Calculer la somme des encaissements du client
                $stmt = $pdo->prepare("SELECT SUM(montant) as montantVerse FROM EncaissementDette WHERE idClient = ?");
                $stmt->execute([$client['idClient']]);
                $montantVerse = $stmt->fetch();

                // Ajouter le total des dettes et le montant encaissé aux informations du client
                $client['totalDette'] = $totalDette['totalDette'] ?? 0;
                $client['montantVerse'] = $montantVerse['montantVerse'] ?? 0;

                // Calculer le montant restant
                $client['montantRestant'] = $client['totalDette'] - $client['montantVerse'];
            }

            return $client;
        } catch (PDOException $e) {
            echo 'Erreur : ' . $e->getMessage();
            return null;
        }
    }
}

