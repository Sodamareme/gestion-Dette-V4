<?php
namespace Controller;

class ExoController {
    public function store() {
        echo "Bonjour";
        
    }
    public function show($id, $date) {
        echo "Affichage de la dette avec l'ID: $id et la date: $date";
        
    }
}
?>
