<?php
namespace Controller;

use Core\Controller;

class ClientsSuiviController extends Controller {
    public function index() {
        // require_once __DIR__ . '/../views/clientsSuiviDette.html.php';
        $this->renderView('clientsSuiviDette');
    }
    
}
?>