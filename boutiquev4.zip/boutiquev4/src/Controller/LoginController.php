<?php
namespace Controller;

class LoginController {
    public function show() {
        require_once __DIR__ . '/../views/login.html.php';
    }
}
?>
