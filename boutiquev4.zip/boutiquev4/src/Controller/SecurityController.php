<?php
// namespace Controller;

// use Core\Controller;
// use Security\SecurityDatabase;

// class SecuriteController extends Controller {
//     private $securityDb;

//     public function __construct() {
//         $this->securityDb = new SecurityDatabase();
//     }

//     public function login($username, $password) {
//         return $this->securityDb->login($username, $password);
//     }

//     public function isLogged() {
//         return $this->securityDb->isLogged();
//     }

//     public function getRoles() {
//         return $this->securityDb->getRoles();
//     }

//     public function getUserLogged() {
//         return $this->securityDb->getUserLogged();
//     }
// }



