<?php
namespace Controller;

use Core\Controller;
use Model\ProprietaireModel;

class ProprietaireController extends Controller {
    private $proprietaireModel;

    public function __construct() {
        $this->proprietaireModel = new ProprietaireModel();
    }

    public function getAllProprietaires() {
        return $this->proprietaireModel->all();
    }

    public function getProprietaireById($id) {
        return $this->proprietaireModel->find($id);
    }

    public function saveProprietaire($data) {
        return $this->proprietaireModel->save($data);
    }

    public function updateProprietaire($id, $data) {
        return $this->proprietaireModel->update($id, $data);
    }

    public function deleteProprietaire($id) {
        return $this->proprietaireModel->delete($id);
    }
}
