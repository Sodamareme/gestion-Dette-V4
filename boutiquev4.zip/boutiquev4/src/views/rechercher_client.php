<?php
header('Content-Type: application/json');

// Configuration de la base de données
$host = 'localhost';
$dbname = 'boutiquev4';
$user = 'soda';
$password = 'soda1616';

try {
    // Connexion à la base de données
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Vérification de la méthode de requête
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $tel = $_POST['tel'];

        // Afficher le numéro de téléphone recherché pour le débogage
        error_log('Numéro de téléphone recherché: ' . $tel);

        // Préparation de la requête SQL pour rechercher le client par téléphone
        $stmt = $pdo->prepare('SELECT * FROM clients WHERE tel = :tel');
        $stmt->execute(['tel' => $tel]);

        // Récupération du résultat
        $client = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($client) {
            echo json_encode([
                'success' => true,
                'nom' => $client['nom'],
                'prenom' => $client['prenom'],
                'email' => $client['email'],
                'photo' => $client['photo']
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Aucun client trouvé avec ce numéro de téléphone.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Méthode de requête non autorisée.']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur lors de la connexion à la base de données: ' . $e->getMessage()]);
}
?>
