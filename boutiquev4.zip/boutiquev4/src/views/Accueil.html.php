<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Boutique</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f4f8;
        }
        h1, h2 {
            font-family: 'Playfair Display', serif;
        }
        .gradient-bg {
            background: linear-gradient(135deg, #6b46c1, #3182ce);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-10px) rotate(2deg);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        .nav-link {
            position: relative;
            overflow: hidden;
        }
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background-color: #6b46c1;
            transition: width 0.3s ease;
        }
        .nav-link:hover::after {
            width: 100%;
        }
        .btn-hover {
            transition: all 0.3s ease;
        }
        .btn-hover:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 14px rgba(50, 50, 93, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08);
        }
        .shape {
            position: absolute;
            opacity: 0.1;
        }
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }
    </style>
</head>
<body class="text-gray-800">
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
            <a href="index.html" class="text-3xl font-bold text-purple-700 hover:text-purple-800 transition">
                <i class="fas fa-store mr-2"></i>Gestion Boutique
            </a>
            <div class="space-x-8">
                <a href="clientSuiviDette.html.php" class="text-gray-700 hover:text-purple-600 px-3 py-2 transition nav-link"><i class="fas fa-users mr-1"></i>Clients</a>
                <a href="approvisionnements.html" class="text-gray-700 hover:text-purple-600 px-3 py-2 transition nav-link"><i class="fas fa-boxes mr-1"></i>Approvisionnements</a>
                <a href="ventes.html" class="text-gray-700 hover:text-purple-600 px-3 py-2 transition nav-link"><i class="fas fa-cash-register mr-1"></i>Ventes</a>
                <a href="clientsSuiviDette.html.php" class="text-gray-700 hover:text-purple-600 px-3 py-2 transition nav-link"><i class="fas fa-file-invoice-dollar mr-1"></i>Dettes</a>
            </div>
        </div>
    </nav>
    <header class="gradient-bg text-white py-32 relative overflow-hidden">
        <div class="container mx-auto text-center px-6 relative z-10">
            <h1 class="text-6xl font-bold mb-8 animate__animated animate__fadeInDown">Bienvenue dans votre application de gestion de boutique</h1>
            <p class="text-2xl mb-12 animate__animated animate__fadeInUp">Optimisez votre business avec notre solution</p>
            <a href="#main-content" class="bg-white text-purple-700 px-8 py-4 rounded-full font-bold text-lg hover:bg-purple-100 transition btn-hover inline-block">Découvrir</a>
        </div>
        <div class="shape bg-white w-64 h-64 rounded-full absolute top-1/4 left-1/4 transform -translate-x-1/2 -translate-y-1/2" style="animation: float 6s ease-in-out infinite;"></div>
        <div class="shape bg-purple-300 w-48 h-48 rounded-full absolute bottom-1/4 right-1/4 transform translate-x-1/2 translate-y-1/2" style="animation: float 8s ease-in-out infinite;"></div>
    </header>
    <main id="main-content" class="container mx-auto px-6 py-24">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            <!-- Card for Clients -->
            <div class="bg-white shadow-xl rounded-lg p-8 hover:shadow-2xl transition card-hover">
                <i class="fas fa-users text-6xl text-purple-500 mb-6"></i>
                <h2 class="text-3xl font-bold mb-4">Gestion des Clients</h2>
                <p class="mb-6 text-gray-600">Centralisez et gérez efficacement toutes les informations de vos clients.</p>
                <a href="clients.html" class="bg-purple-600 text-white px-6 py-3 rounded-full transition hover:bg-purple-700 inline-block btn-hover"><i class="fas fa-arrow-right mr-2"></i>Gérer les Clients</a>
            </div>
            <!-- Card for Approvisionnements -->
            <div class="bg-white shadow-xl rounded-lg p-8 hover:shadow-2xl transition card-hover">
                <i class="fas fa-boxes text-6xl text-blue-500 mb-6"></i>
                <h2 class="text-3xl font-bold mb-4">Gestion des Stocks</h2>
                <p class="mb-6 text-gray-600">Optimisez vos approvisionnements et suivez vos stocks en temps réel.</p>
                <a href="approvisionnements.html" class="bg-blue-600 text-white px-6 py-3 rounded-full transition hover:bg-blue-700 inline-block btn-hover"><i class="fas fa-arrow-right mr-2"></i>Gérer les Stocks</a>
            </div>
            <!-- Card for Ventes -->
            <div class="bg-white shadow-xl rounded-lg p-8 hover:shadow-2xl transition card-hover">
                <i class="fas fa-cash-register text-6xl text-green-500 mb-6"></i>
                <h2 class="text-3xl font-bold mb-4">Suivi des Ventes</h2>
                <p class="mb-6 text-gray-600">Analysez vos performances et optimisez vos stratégies de vente.</p>
                <a href="clientsSuiviDette.html.php" class="bg-green-600 text-white px-6 py-3 rounded-full transition hover:bg-green-700 inline-block btn-hover"><i class="fas fa-arrow-right mr-2"></i>Gérer les Ventes</a>
            </div>
            <!-- Card for Dettes -->
            <div class="bg-white shadow-xl rounded-lg p-8 hover:shadow-2xl transition card-hover">
                <i class="fas fa-file-invoice-dollar text-6xl text-red-500 mb-6"></i>
                <h2 class="text-3xl font-bold mb-4">Gestion des Dettes</h2>
                <p class="mb-6 text-gray-600">Suivez et gérez efficacement les dettes pour une meilleure trésorerie.</p>
                <a href="clientsSuiviDette.html.php" class="bg-red-600 text-white px-6 py-3 rounded-full transition hover:bg-red-700 inline-block btn-hover"><i class="fas fa-arrow-right mr-2"></i>Gérer les Dettes</a>
            </div>
        </div>
    </main>
    <footer class="bg-gray-800 text-white py-12 mt-24">
        <div class="container mx-auto px-6 text-center">
            <p class="text-lg mb-4">&copy; 2024 Gestion Boutique. Tous droits réservés.</p>
            <div class="flex justify-center space-x-6 mb-8">
                <a href="#" class="text-gray-400 hover:text-white transition"><i class="fab fa-facebook-f fa-lg"></i></a>
                <a href="#" class="text-gray-400 hover:text-white transition"><i class="fab fa-twitter fa-lg"></i></a>
                <a href="#" class="text-gray-400 hover:text-white transition"><i class="fab fa-instagram fa-lg"></i></a>
                <a href="#" class="text-gray-400 hover:text-white transition"><i class="fab fa-linkedin-in fa-lg"></i></a>
            </div>
            <div class="flex flex-wrap justify-center">
                <a href="#" class="text-gray-400 hover:text-white mx-3 my-2 transition">Politique de confidentialité</a>
                <a href="#" class="text-gray-400 hover:text-white mx-3 my-2 transition">Conditions d'utilisation</a>
                <a href="#" class="text-gray-400 hover:text-white mx-3 my-2 transition">Contact</a>
            </div>
        </div>
    </footer>
</body>
</html>