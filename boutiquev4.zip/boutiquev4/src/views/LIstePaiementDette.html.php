<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Dettes</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-blue-50">
    <div class="max-w-4xl mx-auto p-8">
        <div class="bg-blue-500 text-white text-center py-4 rounded-t-lg">
            <h1 class="text-2xl font-bold">Liste des Dettes</h1>
        </div>
        <div class="bg-white p-4 rounded-b-lg shadow-md">
            <div class="mb-4">
                <label for="montant" class="block text-gray-700 font-bold mb-2">Montant</label>
                <select id="montant" class="block w-full border border-gray-300 rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:border-blue-500">
                    <option value="restant">Restant</option>
                </select>
            </div>
            <table class="min-w-full bg-white">
                <thead class="bg-blue-500 text-white">
                    <tr>
                        <th class="w-1/3 py-2">Date</th>
                        <th class="w-1/3 py-2">Montant</th>
                        <th class="w-1/3 py-2">Liste</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="border px-4 py-2"></td>
                        <td class="border px-4 py-2"></td>
                        <td class="border px-4 py-2 text-center">
                            <button class="bg-blue-500 text-white font-bold py-2 px-4 rounded">Paiement</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2"></td>
                        <td class="border px-4 py-2"></td>
                        <td class="border px-4 py-2 text-center">
                            <button class="bg-blue-500 text-white font-bold py-2 px-4 rounded">Paiement</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2"></td>
                        <td class="border px-4 py-2"></td>
                        <td class="border px-4 py-2 text-center">
                            <button class="bg-blue-500 text-white font-bold py-2 px-4 rounded">Paiement</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2"></td>
                        <td class="border px-4 py-2"></td>
                        <td class="border px-4 py-2 text-center">
                            <button class="bg-blue-500 text-white font-bold py-2 px-4 rounded">Paiement</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
