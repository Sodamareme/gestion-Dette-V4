<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Clients et Dettes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="./rechercher_client.php">
    <style>
        .error-message {
            color: red;
            font-size: 0.75rem;
        }
    </style>
</head>

<body class="bg-blue-50 flex items-center justify-center min-h-screen p-4">
    <div class="flex space-x-4 w-full max-w-4xl">
        <!-- Nouveau Client -->
        <div class="bg-white rounded-lg shadow-lg w-1/2">
            <div class="bg-blue-500 text-white text-xl font-bold py-3 px-6 rounded-t-lg">
                Nouveau Client
            </div>
            <form action="/saveClient" method="post" enctype="multipart/form-data" class="p-6 space-y-4" ">
                <div>
                    <label for="nom" class="block text-sm font-medium text-gray-700 mb-1">Nom</label>
                    <input type="text" id="nom" name="nom" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <span id="errorNom" class="error-message"><?=isset($error["nom"])?$error["nom"]:''?></span>
                </div>
                <div>
                    <label for="prenom" class="block text-sm font-medium text-gray-700 mb-1">Prénom</label>
                    <input type="text" id="prenom" name="prenom" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <span id="errorPrenom" class="error-message"><?=isset($error["prenom"])?$error["prenom"]:''?></span>
                </div>
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input type="email" id="email" name="email" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <span id="errorEmail" class="error-message"><?=isset($error["email"])?$error["email"]:''?></span>
                </div>
                <div>
                    <label for="tel" class="block text-sm font-medium text-gray-700 mb-1">Tel</label>
                    <input type="tel" id="tel" name="tel" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <span id="errorTel" class="error-message"><?=isset($error["tel"])?$error["tel"]:''?></span>
                </div>
                <div>
                    <label for="photo" class="block text-sm font-medium text-gray-700">Photo</label>
                    <input type="file" id="photo" name="photo" class="text-gray-700 mt-1 block w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-500 file:text-white hover:file:bg-primary-600">
                    <span id="errorPhoto" class="error-message"><?=isset($error["photo"])?$error["photo"]:''?></span>
                </div>

                <button type="submit" class="w-full bg-green-500 text-white py-2 px-4 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500">
                    Enregistrer
                </button>
            </form>
            <div class="w-full text-green-500 text-3xl">
                <?=isset($sucess)?$sucess:""?>
            </div>
        </div>

    </div>
    </div>

    <!-- Suivi Dette -->

    <div class="bg-white rounded-lg shadow-lg w-1/2">
        <div class="bg-blue-500 text-white text-xl font-bold py-3 px-6 rounded-t-lg">
            Suivi Dette
        </div>
        <form method="POST" action="/searchClient" class="p-6 space-y-4">
            <div class="p-6 space-y-4">
                <div class="flex space-x-2">
                    <input type="tel" id="telRecherche" placeholder="Numéro de téléphone" name="telRecherche" class="flex-grow px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <button type="submit" id="btnRechercher" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        Rechercher
                    </button>
                </div>
                <div class="bg-gray-100 p-4 rounded-md">
                    <?php if (isset($client)) : ?>
                        <div class="flex space-x-2 mb-4">
                            <button class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                Client
                            </button>
                            <button class="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500">
                                +Nouvelle
                            </button>
                            <button class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500">
                                Dette
                            </button>
                        </div>
                        <div class="flex space-x-4 items-center">
                            <div class="w-20 h-20 bg-gray-300 rounded-md" id="photoClient">
                                <img src="<?= htmlspecialchars('./uploads/' . ($client['photo'] ?? 'default.png')) ?>" alt="imageClient" class="w-full h-full">
                            </div>
                            <div>
                                <p><span class="font-medium">Nom :</span> <span id="nomClient"><?= htmlspecialchars($client['nom'] ?? '') ?></span></p>
                                <p><span class="font-medium">Prénom :</span> <span id="prenomClient"><?= htmlspecialchars($client['prenom'] ?? '') ?></span></p>
                                <p><span class="font-medium">Email :</span> <span id="emailClient"><?= htmlspecialchars($client['email'] ?? '') ?></span></p>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Total Dette :</label>
                            <input type="text" id="totalDette" value="<?= htmlspecialchars($client['totalDette'] ?? 0) ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Montant Versé :</label>
                            <input type="text" id="montantVerse" value="<?= htmlspecialchars($client['montantVerse'] ?? 0) ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Montant Restant :</label>
                            <input type="text" id="montantRestant" value="<?= htmlspecialchars($client['montantRestant'] ?? 0) ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    <?php else : ?>
                        <p class="text-red-500">Aucune information client disponible.</p>
                    <?php endif; ?>
                </div>
            </div>
    </div>
    </form>
    </div>



</body>


</html>