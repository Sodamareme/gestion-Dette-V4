<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement d'une Dette</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 300px;
        }
        h1 {
            background-color: #4285f4;
            color: white;
            padding: 10px;
            margin: -20px -20px 20px -20px;
            border-radius: 8px 8px 0 0;
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #34a853;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Paiement d'une Dette</h1>
        <form>
            <label for="client">Client :</label>
            <input type="text" id="client" name="client">
            
            <label for="montant">Montant :</label>
            <input type="text" id="montant" name="montant">
            
            <label for="montantVerse">Montant versé :</label>
            <input type="text" id="montantVerse" name="montantVerse">
            
            <label for="montantRestant">Montant Restant :</label>
            <input type="text" id="montantRestant" name="montantRestant">
            
            <label for="montantPaiement">Montant :</label>
            <input type="text" id="montantPaiement" name="montantPaiement">
            
            <button type="submit">OK</button>
        </form>
    </div>
</body>
</html>