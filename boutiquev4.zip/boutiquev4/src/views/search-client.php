<?php
// Inclure le fichier du contrôleur
require_once '../Controller/UtilisateurController.php';

// Créer une instance du contrôleur
$controller = new Controller\UtilisateurController();

// Appeler la méthode de recherche de client
$controller->searchClient();
?>
