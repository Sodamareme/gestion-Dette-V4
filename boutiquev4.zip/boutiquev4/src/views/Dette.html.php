<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dettes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-blue-50 flex items-center justify-center min-h-screen p-4">
    <div class="bg-white rounded-lg shadow-lg w-full max-w-2xl">
        <div class="bg-blue-500 text-white text-xl font-bold py-3 px-6 rounded-t-lg">
            Dettes
        </div>
        
        <div class="p-6">
            <div class="grid grid-cols-2 gap-4 mb-6">
                <div>
                    <label for="client" class="block text-sm font-medium text-gray-700 mb-1">Client :</label>
                    <input type="text" id="client" placeholder="Client" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label for="tel" class="block text-sm font-medium text-gray-700 mb-1">Tel :</label>
                    <input type="text" id="tel" placeholder="Tel" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>

            <div class="flex items-center mb-4">
                <span class="mr-2 font-medium">MONTANT</span>
                <div class="relative">
                    <select class="appearance-none bg-white border border-gray-300 text-blue-500 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:border-blue-500">
                        <option>Restant</option>
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-blue-500">
                        <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                            <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" fill-rule="evenodd"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <table class="w-full mb-6">
                <thead>
                    <tr class="bg-blue-500 text-white">
                        <th class="py-2 px-4 text-left">Date</th>
                        <th class="py-2 px-4 text-left">Montant</th>
                        <th class="py-2 px-4 text-left">Restant</th>
                        <th class="py-2 px-4 text-left">Paiement</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4">
                            <button class="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-blue-600 focus:outline-none">
                                <i class="fas fa-plus"></i>
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4">
                            <button class="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-blue-600 focus:outline-none">
                                <i class="fas fa-plus"></i>
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4">
                            <button class="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-blue-600 focus:outline-none">
                                <i class="fas fa-plus"></i>
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4"></td>
                        <td class="border py-2 px-4">
                            <button class="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-blue-600 focus:outline-none">
                                <i class="fas fa-plus"></i>
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>

            <div class="text-right">
                <button class="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500">
                    Liste →
                </button>
            </div>
        </div>
    </div>
</body>
</html>