<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            background-color: #f0f4f8; /* Couleur de fond neutre */
        }
        .container {
            display: grid;
            grid-template-columns: 1fr 1fr; /* Deux colonnes, une pour le formulaire, l'autre pour l'image */
            align-items: center;
            max-width: 1200px; /* Largeur maximale du conteneur  */
            width: 100%;
            padding: 1.5rem; /* Espacement intérieur  */
        }
        .image-container {
            background-image: url('../src/images/login.png'); /* Chemin vers votre image */
            background-repeat: no-repeat; /* Empêche la duplication de l'image */
            background-size: cover;      /* Couvre toute la surface de l'élément */
            background-position: center center; /* Centre l'image */
            height: 100%; /* Hauteur complète de l'élément parent */
            border-radius: 15px; /* Coins arrondis */
        }
        .form-container {
              background-color: green; /* Couleur de fond du formulaire */
            padding: 2.5rem; /* Espacement intérieur du formulaire (augmenté) */
            border-radius: 15px; /* Coins arrondis */
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Ombre légère */
            max-width: 450px; /* Largeur maximale du formulaire (augmentée) */
            width: 100%;
            min-height: 500px; /* Hauteur minimale du formulaire (augmentée) */
        }
        .logo {
            width: 6rem;
            height: 6rem;
            margin-bottom: 1.5rem;
        }
        .logo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
            box-shadow: 0 0 3px rgba(95, 95, 95, 0.5), 0 0 0 5px #ecf0f3, 8px 8px 15px rgba(167, 170, 167, 0.5), -8px -8px 15px #fff;
        }
        .btn {
            background-color: #039BE5; /* Couleur de fond du bouton */
        }
        .btn:hover {
            background-color: #0288D1; /* Couleur de fond du bouton au survol */
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Formulaire -->
        <div class="form-container">
            <div class="logo mx-auto mb-4">
                <img src="../src/images/login1.png" alt="Logo" class="w-full h-full object-cover rounded-full shadow-[0_0_3px_#5f5f5f,0_0_0_5px_#ecf0f3,8px_8px_15px_#a7aaa7,-8px_-8px_15px_#fff]">
            </div>
            <div class="name text-center mt-4 text-2xl font-semibold tracking-wider text-white">
                ECD
            </div>
            <div id="formContainer">
                <!-- Login Form -->
                <form method="post" class="p-3 mt-3" id="loginForm">
                    <input type="hidden" name="login">
                    <div class="form-field relative flex items-center p-2 mb-2 bg-white rounded-full ">
                        <span class="fas fa-user text-gray-500 pl-4"></span>
                        <input type="text" name="userName" id="loginUserName" placeholder="Email" class="pl-3 pr-4 text-lg text-gray-700 outline-none bg-transparent w-full rounded-full">
                    </div>
                    <div id="loginEmailError" class="text-red-500 text-xs italic mb-4 hidden">Please enter a valid email.</div>
                    <div class="form-field relative flex items-center p-2 mb-2 bg-white rounded-full ">
                        <span class="fas fa-key text-gray-500 pl-4"></span>
                        <input type="password" name="password" id="loginPwd" placeholder="Password" class="pl-3 pr-4 text-lg text-gray-700 outline-none bg-transparent w-full rounded-full">
                    </div>
                    <div id="loginPasswordError" class="text-red-500 text-xs italic mb-4 hidden">Password must be at least 6 characters long.</div>
                    <button type="submit" class="btn w-full py-2 mt-4 text-white rounded-full bg-green-300 shadow-[3px_3px_3px_#b1b1b1,-3px_-3px_3px_#fff] hover:bg-[#039BE5]">
                        Login
                    </button>
                </form>
                <!-- Register Form -->
                <form class="p-3 mt-3 hidden" id="registerForm">
                    <div class="form-field relative flex items-center p-2 mb-2 bg-white rounded-full shadow-[13px_13px_20px_#cbced1,-13px_-13px_20px_#fff]">
                        <span class="fas fa-user text-gray-500 pl-4"></span>
                        <input type="text" name="userName" id="registerUserName" placeholder="Email" class="pl-3 pr-4 text-lg text-gray-700 outline-none bg-transparent w-full rounded-full">
                    </div>
                    <div id="registerEmailError" class="text-red-500 text-xs italic mb-4 hidden">Please enter a valid email.</div>
                    <div class="form-field relative flex items-center p-2 mb-2 bg-white rounded-full shadow-[13px_13px_20px_#cbced1,-13px_-13px_20px_#fff]">
                        <span class="fas fa-key text-gray-500 pl-4"></span>
                        <input type="password" name="password" id="registerPwd" placeholder="Password" class="pl-3 pr-4 text-lg text-gray-700 outline-none bg-transparent w-full rounded-full">
                    </div>
                    <div id="registerPasswordError" class="text-red-500 text-xs italic mb-4 hidden">Password must be at least 6 characters long.</div>
                    <button type="submit" class="btn w-full py-2 mt-4 text-white rounded-full shadow-[3px_3px_3px_#b1b1b1,-3px_-3px_3px_#fff] hover:bg-[#039BE5]">
                        Register
                    </button>
                </form>
            </div>
            <div class="text-center text-sm text-gray-600 mt-4">
                <a href="#" id="toggleForm" class="text-[#03A9F4] hover:text-[#039BE5]">Sign up</a> <a href="#" id="toggleFormLogin" class="text-[#03A9F4] hover:text-[#039BE5] hidden">Login</a>
            </div>
        </div>
        <!-- Image Container -->
        <div class="image-container"></div>
    </div>

    <script type="module" src="./dist/map.js"></script>
    <script type="module" src="./dist/cargo-impl.js"></script>
</body>
</html>
