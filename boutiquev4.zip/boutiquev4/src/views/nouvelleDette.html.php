<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enregistrer Une Nouvelle Dette</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        <div class="bg-blue-500 text-white text-xl font-bold py-4 px-6">
            Enregistrer Une Nouvelle Dette
        </div>
        
        <div class="p-6">
            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label for="client" class="block text-sm font-medium text-gray-700 mb-1">Client :</label>
                    <input type="text" id="client" placeholder="Client" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label for="tel" class="block text-sm font-medium text-gray-700 mb-1">Tel :</label>
                    <input type="text" id="tel" placeholder="Tel" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>

            <div class="bg-blue-50 p-4 rounded-md mb-4">
                <div class="mb-4">
                    <label for="ref" class="block text-sm font-medium text-gray-700 mb-1">Ref :</label>
                    <div class="flex">
                        <input type="text" id="ref" placeholder="Ref" class="flex-grow px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <button class="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">Ok</button>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-4 mb-4">
                    <div>
                        <label for="libelle" class="block text-sm font-medium text-gray-700 mb-1">Libellé :</label>
                        <input type="text" id="libelle" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="prix" class="block text-sm font-medium text-gray-700 mb-1">Prix :</label>
                        <input type="text" id="prix" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div class="flex items-end">
                        <input type="text" id="quantite" placeholder="Quantité" class=" w-full px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <button class="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">Ok</button>
                    </div>
                </div>

                <table class="w-full mb-4">
                    <thead>
                        <tr class="bg-blue-500 text-white">
                            <th class="py-2 px-4 text-left">Article</th>
                            <th class="py-2 px-4 text-left">Prix</th>
                            <th class="py-2 px-4 text-left">Quantité</th>
                            <th class="py-2 px-4 text-left">Montant</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td></tr>
                        <tr><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td></tr>
                        <tr><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td></tr>
                        <tr><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td><td class="border py-2 px-4"></td></tr>
                    </tbody>
                </table>

                <div class="text-right mb-4">
                    <span class="font-medium">Total : </span>
                    <span id="total">______</span>
                </div>

                <div class="text-right">
                    <button class="bg-green-500 text-white px-6 py-2 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500">Enregistrer</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>