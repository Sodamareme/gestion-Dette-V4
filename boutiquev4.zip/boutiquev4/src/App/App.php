<?php
namespace App;

use Database\MysqlDatabase;

class App {
    private static $instance;
    private $database;

    private function __construct() {
        $this->database = MysqlDatabase::getInstance();
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getDatabase() {
        return $this->database;
    }

    public function getModel($model) {
        $class = "Model\\" . ucfirst($model) . "Model";
        return new $class($this->database);
    }

    public function notFound() {
        // Implement notFound logic
    }

    public function forbidden() {
        // Implement forbidden logic
    }
}
