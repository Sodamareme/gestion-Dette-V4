<?php
namespace Database;

use \PDO;

class MysqlDatabase {
    private static $instance;
    private $pdo;

    private function __construct() {
        $this->pdo = new PDO(
            'mysql:host=' . getenv('DB_HOST') . ';dbname=' . getenv('DB_NAME'),
            getenv('DB_USER'),
            getenv('DB_PASS')
        );
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function query($statement, $attributes = null) {
        if ($attributes) {
            $req = $this->pdo->prepare($statement);
            $req->execute($attributes);
            return $req->fetchAll(PDO::FETCH_OBJ);
        } else {
            return $this->pdo->query($statement)->fetchAll(PDO::FETCH_OBJ);
        }
    }

    public function prepare($statement, $attributes) {
        $req = $this->pdo->prepare($statement);
        $req->execute($attributes);
        return $req->fetchAll(PDO::FETCH_OBJ);
    }
}
// namespace src\Database;
// return [
//     'database' => [
//         'dsn' => 'mysql:host=localhost;dbname=gestionboutiquecomposer',
//         'username' => 'soda',
//         'password' => 'soda1616',
//     ],
// ];
// use PDO;

// class MysqlDatabase {
//     private $pdo;

//     public function __construct($config) {
//         $this->pdo = new PDO($config['dsn'], $config['username'], $config['password']);
//         $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//     }

//     public function query($sql, $params = []) {
//         $stmt = $this->pdo->prepare($sql);
//         $stmt->execute($params);
//         return $stmt;
//     }
// }