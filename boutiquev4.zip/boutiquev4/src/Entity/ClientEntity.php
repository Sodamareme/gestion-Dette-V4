<?php
namespace Entity;

use Core\Entity;

class ClientEntity extends Entity {
    protected $id;
    protected $nom;
    protected $prenom;
}

