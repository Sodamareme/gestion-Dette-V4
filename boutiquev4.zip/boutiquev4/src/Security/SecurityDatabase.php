<?php
namespace Security;

use Database\MysqlDatabase;

class SecurityDatabase {
    private $database;

    public function __construct() {
        $this->database = MysqlDatabase::getInstance();
    }

    public function login($username, $password) {
        $sql = "SELECT * FROM Utilisateur WHERE login = ? AND mdp = ?";
        $user = $this->database->query($sql, [$username, $password]);
        if ($user) {
            // Implement session handling and return user details
        }
        return null;
    }

    public function isLogged(): bool {
        // Implement session check
    }

    public function getRoles() {
        // Implement roles retrieval
    }

    public function getUserLogged() {
        // Implement logged-in user retrieval
    }
}


