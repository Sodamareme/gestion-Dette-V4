<?php

return [
    'database' => [
        'dsn' => 'mysql:host=localhost;dbname=gestionboutiquecomposer',
        'username' => 'soda',
        'password' => 'soda1616',
    ],
];