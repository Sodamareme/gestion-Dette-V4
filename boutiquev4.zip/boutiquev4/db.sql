
SHOW TABLES;
-- Insérer des données dans la table Propriete
INSERT INTO Proprietaire (photo, nom, prenom, code, adresse, telephone, login, password) 
VALUES 
('photo1.jpg', 'Diop', 'Mareme', 'PR001', 'Adresse 1', '123456789', 'mareme.diop', 'password1'),
('photo2.jpg', 'Sarr', 'Awa', 'PR002', 'Adresse 2', '987654321', 'awa.sarr', 'password2');

-- Insérer des données dans la table Client
INSERT INTO Client (photo, nom, prenom, code, email, tel, login, password, idProprietaire) 
VALUES 
('photo3.jpg', 'Ndiaye', 'Aliou', '001', 'Adresse 3', '123456789', 'aliou.ndiaye', 'password3', 1),
('photo4.jpg', 'Ba', 'Mamadou', '002', 'Adresse 4', '987654321', 'mamadou.ba', 'password4', 2);

-- Insérer des données dans la table Vendeur
INSERT INTO Vendeur (photo, nom, prenom, code, adresse, telephone, login, mdp) 
VALUES 
('photo5.jpg', 'Sene', 'Fatou', 'VN001', 'Adresse 5', '123456789', 'fatou.sene', 'password5'),
('photo6.jpg', 'Dieng', 'Cheikh', 'VN002', 'Adresse 6', '987654321', 'cheikh.dieng', 'password6');

-- Insérer des données dans la table Produit
INSERT INTO Produit (libelle, code, qte, prix, type, idProprietaire) 
VALUES 
('Produit 1', 'PD001', 10, 1000.00, 'Type 1', 1),
('Produit 2', 'PD002', 20, 2000.00, 'Type 2', 2);

-- Insérer des données dans la table Utilisateur
INSERT INTO Utilisateur (photo, nom, prenom, code, adresse, telephone, login, mdp) 
VALUES 
('photo7.jpg', 'Fall', 'Khadija', 'UT001', 'Adresse 7', '123456789', 'khadija.fall', 'password7'),
('photo8.jpg', 'Diouf', 'Ibrahima', 'UT002', 'Adresse 8', '987654321', 'ibrahima.diouf', 'password8');

-- Insérer des données dans la table Dette
INSERT INTO Dette (DateEcheance, DateDepart, montant, numero, typeDette, idClient, idProprietaire, idVendeur) 
VALUES 
('2024-12-31', '2024-01-01', 5000.00, 'DT001', 'Type 1', 1, 1, 1),
('2024-11-30', '2024-02-01', 6000.00, 'DT002', 'Type 2', 22, 2, 2);

-- Insérer des données dans la table Paiement
INSERT INTO Paiement (Date, numeroPaiement, montantVerser, montantRestant, idClient, idVendeur, idProprietaire) 
VALUES 
('2024-07-01', 'PM001', 2500.00, 2500.00, 1, 1, 1),
('2024-07-02', 'PM002', 3000.00, 3000.00, 2, 2, 2);

-- Insérer des données dans la table EncaissementDette
INSERT INTO EncaissementDette (libelle, montant, date, idProprietaire, idVendeur, idDette, idClient) 
VALUES 
('Encaissement 3', 1000.00, '2024-07-01', 1, 1, 3, 1),
('Encaissement 4', 2000.00, '2024-07-02', 2, 2, 4, 22);

-- Insérer des données dans la table Compte
INSERT INTO Compte (nom, typeCompte, montantVerse, montantEncaisser, montantRestant, idClient, idProprietaire) 
VALUES 
('Compte 1', 'Type 1', 3000.00, 1000.00, 2000.00, 1, 1),
('Compte 2', 'Type 2', 4000.00, 2000.00, 2000.00, 2, 2);

-- Insérer des données dans la table DetailsClient
INSERT INTO DetailsClient (Produit, MontantDette, MontantVerse, MontantRestant, idProprietaire) 
VALUES 
('Produit 1', 5000.00, 2500.00, 2500.00, 1),
('Produit 2', 6000.00, 3000.00, 3000.00, 2);


SELECT SUM(montant) as totalDette FROM Dette WHERE idClient = 1;